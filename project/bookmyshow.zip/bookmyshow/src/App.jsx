import React from "react";
import FetchDataExample from './FetchDataExample';

function App() {
  return (
    <>
      <FetchDataExample />
    </>
  );
}

export default App;
