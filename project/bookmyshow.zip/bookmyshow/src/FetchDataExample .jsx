import React, { useEffect, useState } from 'react';
import './FetchDataExample.css'; // Optional: Custom styling

const FetchDataExample = () => {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetch('https://mocki.io/v1/613711d0-f780-40cb-969c-ab1b2120697a')
      .then((response) => {
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        return response.json();
      })
      .then((data) => {
        console.log(data);
        
        setMovies(data.movies); // Assuming 'movies' is the key in the response
        setLoading(false);
      })
      .catch((error) => {
        setError(error.message);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <div className="text-center">Loading...</div>;
  }

  if (error) {
    return <div className="text-center text-danger">Error: {error}</div>;
  }

  return (
    <div className="container mt-4">
      <h2 className="text-center mb-4">Now Showing 🎬</h2>
      <div className="row">
        {movies.map((movie, index) => (
          <div key={index} className="col-md-4 mb-4">
            <div className="card">
              <img src={movie.image} alt={movie.name} className="card-img-top" />
              <div className="card-body">
                <h5 className="card-title">{movie.name}</h5>
                <p className="card-text">{movie.description}</p>
                <p className="card-text">🎟️ ₹{movie.price}</p>
                <a href="#" className="btn btn-primary">Book Now</a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FetchDataExample;
